import UIKit
import Foundation


/*
 Print number of occurences of each element in array
 example:
 input: [1, 2, 3, 4, 4, 3, 4, 1, 1, 4, 9]
 output:
 1 3
 2 1
 3 2
 4 4
 9 1
 */

func occurences(_ input: [Int]) {
    
}
